using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class OrbChasescript : MonoBehaviour
{
    public Transform orbtarget;
    public float orbspeed;
    private Rigidbody2D rb;
    private Vector2 orbshift;

    private void Start()
    {
        rb = this.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 direction = orbtarget.position - transform.position;
        Debug.Log(direction);
        direction.Normalize();
        orbshift = direction;

    }
    private void FixedUpdate()
    {
        moveCharacter(orbshift);
    }
    void moveCharacter(Vector2 direction)
    {
        rb.MovePosition((Vector2)transform.position + (direction * orbspeed * Time.deltaTime));
    }

}


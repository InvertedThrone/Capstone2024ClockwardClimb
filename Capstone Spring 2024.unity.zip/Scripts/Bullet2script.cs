using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet2Script : MonoBehaviour
{
    public float speed = 6f;
    public Rigidbody2D rb2;
    public float destroytime = 10f;
    private float timer = 0;
    public int damage = 50;

    // Start is called before the first frame update
    void Start()
    {
        rb2.velocity = speed  * -transform.right ;
    }

    // Update is called once per frame
    void Update()
    {
        if (timer < destroytime)
        {
            timer += Time.deltaTime;
        }
        else
        {
            Debug.Log("Too far");
            Destroy(gameObject);
        }
    }
    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        if (hitInfo.tag != "Player")
        {


            Debug.Log(hitInfo.name);
            healthscript Player = hitInfo.GetComponent<healthscript>();
            if (Player != null)
            {
                Player.turnclockwise(damage);
                Destroy(gameObject);
            }
            if (Player != null)
            {
                Destroy(gameObject);
            }
        }
    }
}

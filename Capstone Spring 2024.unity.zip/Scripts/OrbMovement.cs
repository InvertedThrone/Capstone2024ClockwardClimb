using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class OrbMovement : MonoBehaviour
{
    public Rigidbody2D rb;
    public float moveSpeed = 20f;
    public float jumpingpower = 20f;
    private float horizontal;
    public float deadzone = -20;


    [SerializeField] private Transform groundcheck;
    [SerializeField] private LayerMask groundLayer;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.y < deadzone)
        {
            SceneManager.LoadScene("orb");
        }

        horizontal = Input.GetAxisRaw("Altmove");
        if (Input.GetButtonDown("AltJump") && orbGrounded())
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpingpower);
        }
        if (Input.GetButtonUp("AltJump") && rb.velocity.y > 0f)
        {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * .5f);
        }



        bool orbGrounded()
        {

            return Physics2D.OverlapCircle(groundcheck.position, .2f, groundLayer);

        }

    }
    void FixedUpdate()
    {
        rb.velocity = new Vector2(horizontal * moveSpeed, rb.velocity.y);
    } 



}


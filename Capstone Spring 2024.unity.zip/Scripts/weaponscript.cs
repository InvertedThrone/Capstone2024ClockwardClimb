using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class weaponscript : MonoBehaviour
{
    public Transform firepoint;
    public GameObject BulletPrefab;
    public GameObject BulletPrefab2;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            Shoot();
        }
        if (Input.GetButtonDown("Fire2"))
        {
            Shoot2();
        }
    }
    void Shoot()
    {
        Instantiate(BulletPrefab, firepoint.position, firepoint.rotation);
    }
    void Shoot2()
    {
        Instantiate(BulletPrefab2, firepoint.position, firepoint.rotation);
    }
}

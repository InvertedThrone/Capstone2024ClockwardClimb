using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class healthscript : MonoBehaviour
{
    public int health = 50;

public void turncounterclockwise (int damage)
    {
        health -= damage;

        if (health <= 0 )
        {
            Die();
                }
    }
  public void turnclockwise (int damage)
    {
        health -= damage;
        if (health <= 0 ) 
        { 
            moveclockwise(); }
    }
    void Die()
    { transform.Rotate(Vector3.forward, 45); }
    void moveclockwise()
    {
        transform.Rotate(Vector3.back, 45);
    }
}

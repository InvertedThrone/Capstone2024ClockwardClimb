using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotatewithmousescript : MonoBehaviour
{
    public GameObject visual;
    private Vector3 mouseposit;
    private Rigidbody2D rb;
    public Camera cam;
    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        {
            mouseposit = cam.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, transform.position.z));
            Vector3 difference = mouseposit - visual.transform.position;
            float rotationZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg - 180f;
            rb.rotation = rotationZ;

        }
    }
}

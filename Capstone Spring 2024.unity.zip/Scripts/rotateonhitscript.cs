
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class rotateonhitscript : MonoBehaviour
{
    public logicScript logic;

    // Start is called before the first frame update
    void Start()
    {
        logic = GameObject.FindGameObjectWithTag("Logic").GetComponent<logicScript>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire2"))
        {
            logic.rotatingbar(45);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Bullet")
        {
            Debug.Log("counterclockwise");
            logic.rotatingbar(45);
        }
        if (collision.tag == "Bullet2")
        {
            Debug.Log("clockwise");
            logic.reversingbar(135);
        }
    }

    void rotatingbar()
    {
        transform.Rotate(Vector3.forward, 45);
    }
    void reversingbar()
    {
        transform.Rotate(Vector3.back, 45);
    }
}
